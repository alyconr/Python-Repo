from setuptools import setup
setup(
    name="functions",
    version="0.1",
    description="Este es un paquete que quiero distribuir",
    author="Aly contreras",
    author_email="alyconr473@gmail.com",
    url="http://www.mipagina.com",
    packages=['functions']
)

